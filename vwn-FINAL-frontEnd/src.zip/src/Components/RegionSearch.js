import React, { Component } from 'react';
import regions from '../Data/Map.json';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import Observable from '../Observable';
import '../CSS/RegionSearch.css'

export default class RegionSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            regions: {},
            style: {
                fillOpacity: "1",
                stroke: "white",
                strokeOpacity: "1",
                strokeWidth: "0.5",
                cursor: "pointer"
            },
            hoveredRegion: '',
            selectedRegions: {},
            open: false
        };
        this.handleClick = this.handleClick.bind(this);        
    }

    componentWillMount() {
        this.setState({ regions,
        selectedRegions : Observable.getHash("m")
        })
    }

    handleOpen = () => {
        Observable.setHash("T", 2)
        this.setState({ open: true });     
    };

    handleClose = () => {
        this.setState({ open: false });
    };

    handleClick(e) {
        let { selectedRegions } = this.state
        let region = e.target.id
        if (selectedRegions[region]) {
            selectedRegions[region] = false
        }
        else {
            selectedRegions[region] = true
        }
        Observable.setHash("m", selectedRegions)
        // console.log(selectedRegions)
    }

    render() {
        const { regions, style, hoveredRegion, selectedRegions } = this.state;
        const actions = [
            <FlatButton
                className="popUpBtn"
                label="Ok"
                primary={true}
                keyboardFocused={true}
                onClick={this.handleClose}
            />,
        ];

        return (
            
            <div>
                <FlatButton label="Map" onClick={this.handleOpen} />
                <div>
                <Dialog
                    paperClassName="popUp"
                    title="Please select a region:"
                    titleClassName="dialogTitle"
                    actions={actions}
                    modal={false}
                    open={this.state.open}
                    onRequestClose={this.handleClose}
                >
                    <svg width={400} height={500} viewBox="50 0 400 950" >

                        {
                            Object.keys(regions).map(region => {
                                return (
                                    <g className="regions" key={region}>
                                            <path
                                                fill={region === hoveredRegion ? "#f48101" : "black" && selectedRegions[region] ? "#ed2f25" : "black"}
                                                id={region}
                                                d={regions[region]["path"]}
                                                onClick={this.handleClick}
                                                style={style}
                                                onMouseEnter={() => this.setState({ hoveredRegion: region })}
                                                onMouseOut={() => this.setState({ hoveredRegion: "" })}
                                            >
                                            <title>{regions[region]["title"]}</title>
                                            </path>
                                    </g>
                                );
                            })
                        }
                    </svg>
                </Dialog>
                </div>
            </div>
        )
    }
}