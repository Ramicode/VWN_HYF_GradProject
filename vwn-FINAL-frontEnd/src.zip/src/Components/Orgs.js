import React, { Component } from 'react';
import Observable from '../Observable';
import ContactInfo from './ContactInfo'
import { Card, CardHeader, CardMedia, CardTitle, CardText } from 'material-ui/Card';
// import { Responsive, WidthProvider } from 'react-grid-layout';
import '../CSS/Orgs.css';


// const ResponsiveReactGridLayout = WidthProvider(Responsive);
// var orgObservable = Observable.newStatefullObservable("orgObservable");

class Orgs extends Component {

  constructor(props) {
    super(props)
    this.state = {
      orgs: {},
      orgsAfterFilter: {},
      noFilter: true,
    }
    this.filterOrgsbyId = this.filterOrgsbyId.bind(this)
  }

  componentWillMount() {
    this.setState({
      orgs: this.props.orgs,
    })
    // // this.filterOrgsbyId()
    // Observable.subscribe(tagObservable, this.filterOrgsbyId)
    Observable.subscribe("tagObservable", this.filterOrgsbyId)
    // Observable.subscribe("orgObservable", this.watcher)
    // Observable.updateState("tagObservable", "orgsAfterFilter", this.state.orgsAfterFilter )
  }

//   watcher = (data) => {
//     console.log(data)
//     this.setState({orgsAfterFilter: data})
// }

  filterOrgsbyId = (filters) => {
      let { orgs } = this.state
      let filteredOrgs = {}
      Object.keys(orgs).map(orgID => {
        let filteredOrg = {}
        let org = orgs[orgID]
        const arrayOfTags = org["tags"]
        arrayOfTags.forEach(tagID => {
          if (filters[tagID]) {
            if (filteredOrg.name === undefined) {
              filteredOrg = Object.assign({}, org)
              filteredOrg.id = orgID
            }
          }
        })
        if (filteredOrg.name !== undefined) {
          filteredOrgs[orgID] = Object.assign({}, filteredOrg)
        }
      })
      this.setState({
        orgsAfterFilter: filteredOrgs
      })
  }

  // handleExpandChange = (expanded) => {
  //   this.setState({ expanded: expanded });
  //   console.log(expanded.value)
  // };

  renderOrgs(orgs) {
    return (
      <div className="orgs">
        {/* <ResponsiveReactGridLayout className="layout"
            layout={{x: 1, y: 3, w: 3, h: 3}}
            breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
            cols={{ lg: 3, md: 3, sm: 3, xs: 3, xxs: 3 }}
            draggableCancel= ".card"
            autoSize= {false}
            verticalCompact={false}
            compactType= 'horizontal' 
            preventCollision={true}
                      > */}
        {Object.keys(orgs).map(org => {
          return (
            <div className="cardDIV" key={org}>
              <Card
                initiallyExpanded = {Observable.getHash("o")[org]}
                onExpandChange={(expanded) => 
                 { console.log(expanded)
                  Observable.setHash("o", Number(org), expanded)
                } }
                className="card">
                <CardHeader
                  className="cardHeader"
                  title={orgs[org]["name"]}
                  titleStyle={{ color: "#ed2f25" }}
                  subtitle={orgs[org]["contacts"][0]["city"]}
                  avatar={orgs[org]["logo"]}
                  actAsExpander={true}
                  showExpandableButton={false}
                />
                <CardText className="BTNWrap">
                  <div className="BTN">
                    <ContactInfo orgContacts={orgs[org]["contacts"][0]} />
                  </div>
                </CardText>
                <CardMedia
                  className="TheExpandables4"
                  expandable={true}
                  overlay={<CardTitle title={orgs[org]["name"]}
                    subtitle={orgs[org]["contacts"][0]["web"]} />}
                >
                  <img src={orgs[org]["logo"]} alt="Company logo" width="300px" height="200px" />
                </CardMedia >
                <CardTitle className="TheExpandables4" title={orgs[org]["name"]} subtitle={orgs[org]["contacts"][0]["web"]} expandable={true} />
                <CardText className="TheExpandables4" expandable={true}>
                  {orgs[org]["description_company"]}
                </CardText>
              </Card>
            </div>
          )
        })}
        {/* </ResponsiveReactGridLayout> */}
      </div>
    )
  }

  render() {
    const { orgs, orgsAfterFilter } = this.state
    if (Object.keys(orgsAfterFilter).length === 0) {
      return (<div>{this.renderOrgs(orgs)}</div>)
    }
    else {
      return (
        <div>{this.renderOrgs(orgsAfterFilter)}</div>
      )
    }
  }
}

export default Orgs