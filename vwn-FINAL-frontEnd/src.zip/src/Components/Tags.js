import React, { Component } from 'react'
import Observable from '../Observable';
import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import FlatButton from 'material-ui/FlatButton/FlatButton';
import AppBar from 'material-ui/AppBar';
import '../CSS/Tags.css';

var tagObservable = Observable.newStatefullObservable("tagObservable");

class FilterTags extends Component {
  constructor(props) {
    super(props)
    this.state = {
      tags: {},
      filters: {},
      open: false
    }
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this)
  }

  componentWillMount() {
    this.setState({
      tags: this.props.tags,
      filters: Observable.getHash("t")
    })
    console.log(Observable.getHash("o"))

    // Observable.updateState("tagObservable", "filters", Observable.getHash("t"))
  }

  componentDidMount(){
    Observable.updateState("tagObservable", "filters", Observable.getHash("t"))
  }

  handleCheckboxChange(event) {
    let { filters } = this.state
    let filter = event.target.value
    if (event.target.checked) {
      filters[filter] = true
    } else {
      filters[filter] = false
    }
    Observable.setHash("t", filters)
    Observable.updateState("tagObservable", "filters", filters)
  }

  render() {
    const { tags, open, filters } = this.state
    return (
      <div className="tags">
        <FlatButton
          label="Categories"
          onClick={() => this.setState({ open: !open })}
        />
        <Drawer
          docked={false}
          width={200}
          openSecondary={true}
          open={open}
          onRequestChange={(open) => this.setState({ open })}
        >
          <AppBar title="Categories:"
            showMenuIconButton={false}
            titleStyle={{ color: "#ed2f25" }}
            // zDepth={0}
            className="DTitle" />
          {Object.keys(tags).map(tag => {
            return (
              <MenuItem key={tag} className="item" >
                <input
                  id={tag}
                  className="css-checkbox"
                  type="checkbox"
                  defaultChecked={filters[tag] ? true : false}
                  value={tag}
                  label={tags[tag]}
                  onChange={
                    this.handleCheckboxChange
                  }
                />
                <label className="css-label" htmlFor={tag}>{tags[tag]}</label>
              </ MenuItem>
            )
          })
          }
        </ Drawer>
      </div>
    )
  }
}

export default FilterTags;