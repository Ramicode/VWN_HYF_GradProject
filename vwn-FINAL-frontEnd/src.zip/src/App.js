import React, { Component } from 'react';
import Data from './Data/Data.json';
import Orgs from './Components/Orgs';
import Header from './Components/Header';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './CSS/App.css';

class App extends Component {

  constructor(props) {
    super(props)
    this.state = {
      Data: {},
    }

  }
  componentWillMount() {
    this.setState({
      Data,
    })
  }

  render() {
    const { tags, orgs } = this.state.Data
    return (
      <MuiThemeProvider>
      <div className="app-container">
        <div><Header tags={tags} /></div>
        <div><Orgs orgs={orgs} /></div>
      </div>
      </MuiThemeProvider>
    )
  }
}

export default App;