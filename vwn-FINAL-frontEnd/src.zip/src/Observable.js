class Observable{

   observables = []
  
    subscribe(observable, observer) {
      // console.log(this.observables[`${observable}`])
      this.observables[`${observable}`].observers.push(observer)
      // console.log("subscribed")
    }
  
    unSubscribe(observable, _observer) {
      this.observables[`${observable}`].observers = this.observables[`${observable}`].observers.filter(observer => observer !== _observer)
    }
  
    newStatefullObservable(newObservable) {
      this.observables[`${newObservable}`] = {data:{}, observers:[]}
      // console.log(this.observables.tagObservable)
    }

  
    updateState(observable, stateName, stateValue) {
      // console.log(this.observables[`${observable}`])
      this.observables[`${observable}`].data[`${stateName}`] = stateValue
      this.observables[`${observable}`].observers.map(observer => {
        observer(this.observables[`${observable}`].data[`${stateName}`])
        // console.log('this is even: ', observer)
        return undefined
      })
    }
  
    setHash(URLHead, values, toggle) {
      let URLArray = window.location.hash.slice(1).split(",")
      if (typeof (values) === 'number') {
        let id = URLHead + values
        if (!toggle) {
          URLArray = URLArray.filter(e => {
            if (e[0] !== URLHead) {
              return e
            }
          })
        } else if (URLArray.indexOf(id) === -1) {
          URLArray.push(id)
        }else {
          URLArray = URLArray.filter(val => val !== id)
        }
        window.location.hash = URLArray.join(',')
      } else {
        let arrayOfValues = []
        this.hashURL = []
        for (const id in values) {
          if (values[id]) {
            arrayOfValues.indexOf(URLHead + id) === -1 ? arrayOfValues.push(URLHead + id) : console.log("This item already exists");
            for (const V in arrayOfValues) {
              URLArray.indexOf(arrayOfValues[V]) === -1 ? URLArray.push(arrayOfValues[V]) : console.log("This item already exists");
            }
          } else {
            let toBeRemoved = URLHead + id
            URLArray = URLArray.filter(val => val !== toBeRemoved)
          }
        }
        window.location.hash = URLArray.join(',')
      }
    }
  
    getHash(URLHead) {
      let resultArray = {}
      let URLArray = window.location.hash.slice(1).split(",")
      URLArray.slice(1).map((x) => {
        if (x[0] === URLHead) {
          x = x.substr(1)
          resultArray[x] = true
        }
        return undefined
      })
      return (resultArray)
    }
  }
  
  export default new Observable();
  